import random

# Labirint yaratish: " " - yo'l, "#" - to'siq, "S" - start, "E" - chiqish
labirint = [
    ["#", "#", "#", "#", "#", "#", "#", "#"],
    ["#", "S", " ", " ", "#", " ", "E", "#"],
    ["#", " ", "#", " ", "#", " ", "#", "#"],
    ["#", " ", "#", " ", " ", " ", "#", "#"],
    ["#", " ", " ", "#", "#", " ", " ", "#"],
    ["#", "#", " ", " ", "#", " ", "#", "#"],
    ["#", " ", " ", " ", "#", " ", " ", "#"],
    ["#", "#", "#", "#", "#", "#", "#", "#"]
]

# Boshlang'ich joyni topish
for i in range(len(labirint)):
    for j in range(len(labirint[i])):
        if labirint[i][j] == "S":
            start_x, start_y = i, j

# O'yinchining boshlang'ich joyi
o_x, o_y = start_x, start_y

# Labirintni chop etish funksiyasi
def print_labirint():
    for i in range(len(labirint)):
        for j in range(len(labirint[i])):
            if i == o_x and j == o_y:
                print("O", end=" ")
            else:
                print(labirint[i][j], end=" ")
        print()
    print()

print("Labirintdan chiqishga harakat qiling ('W', 'A', 'S', 'D' tugmalaridan foydalaning).")
print_labirint()

while True:
    move = input("Harakat yo'nalishini tanlang (W/A/S/D): ").upper()
    
    # Yangi joyni hisoblash
    if move == "W":  # yuqoriga
        new_x, new_y = o_x - 1, o_y
    elif move == "S":  # pastga
        new_x, new_y = o_x + 1, o_y
    elif move == "A":  # chapga
        new_x, new_y = o_x, o_y - 1
    elif move == "D":  # o'ngga
        new_x, new_y = o_x, o_y + 1
    else:
        print("Noto'g'ri tugma! Faqat W, A, S, D tugmalarini bosing.")
        continue

    # Chegaralarni va to'siqlarni tekshirish
    if 0 <= new_x < len(labirint) and 0 <= new_y < len(labirint[0]):
        if labirint[new_x][new_y] != "#":  # To'siq bo'lmasa
            o_x, o_y = new_x, new_y
            
            # G'alaba holatini tekshirish
            if labirint[o_x][o_y] == "E":
                print_labirint()
                print("Tabriklaymiz! Siz chiqish joyiga yetib keldingiz!")
                break
        else:
            print("To'siq bor! Boshqa yo'lni tanlang.")
    else:
        print("Chegaradan tashqariga chiqmang!")

    print_labirint()
